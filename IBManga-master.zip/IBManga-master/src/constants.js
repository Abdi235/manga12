const constants = {
  MATERIALS: "Material",
  CHARACTERS: "Characters",
  GET_MATERIALS: 'GET_MATERIALS',
  GET_CHARACTERS: 'GET_CHARACTERS',
}
export default constants