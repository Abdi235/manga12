# IBManga
keep track of your favorite manga

<img src="https://github.com/ibrahim408/IBManga/blob/master/src/img/IBManga.PNG" width="400" height="800" />

<img src="https://github.com/ibrahim408/IBManga/blob/master/src/img/IBManga2.PNG" width="400" height="800" />

<img src="https://github.com/ibrahim408/IBManga/blob/master/src/img/IBManga3.PNG" width="400" height="800" />

<img src="https://github.com/ibrahim408/IBManga/blob/master/src/img/IBManga4.PNG" width="400" height="800" />
